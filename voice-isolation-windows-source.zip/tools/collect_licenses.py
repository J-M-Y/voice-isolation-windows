"""Collect installed third-party license texts for the distributable package.

Run with the project's build environment. Only license/notice files and package
metadata are copied; never copy user recordings or package runtime files.
"""
from importlib import metadata
from pathlib import Path
import shutil


ROOT = Path(__file__).resolve().parent.parent
DEST = ROOT / 'release_materials' / 'third_party'


def is_notice(path):
    lower = str(path).replace('\\', '/').lower()
    name = Path(lower).name
    return ('.dist-info/' in lower and any(token in lower for token in
            ('/licenses/', '/license', '/notice', '/copying'))) or (
            lower.startswith('onnxruntime/') and name in ('license', 'thirdpartynotices.txt'))


def main():
    DEST.mkdir(parents=True, exist_ok=True)
    rows = ['Included packages and their license information', '']
    for dist in sorted(metadata.distributions(), key=lambda d: (d.metadata.get('Name') or '').lower()):
        name = dist.metadata.get('Name')
        if not name:
            continue
        version = dist.version
        safe_name = ''.join(c if c.isalnum() or c in '.-_' else '_' for c in name)
        expression = dist.metadata.get('License-Expression') or dist.metadata.get('License') or 'See license files'
        rows.append(f'{name} {version}: {expression.splitlines()[0]}')
        for entry in dist.files or ():
            if not is_notice(entry):
                continue
            source = Path(dist.locate_file(entry))
            if not source.is_file():
                continue
            # Preserve nested license paths without trusting absolute or parent paths.
            parts = Path(str(entry)).parts
            if any(p in ('..', '.') for p in parts) or Path(str(entry)).is_absolute():
                continue
            dest = DEST / safe_name / Path(*parts)
            dest.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(source, dest)
    (DEST / 'PACKAGES.txt').write_text('\n'.join(rows) + '\n', encoding='utf-8')
    # pystray is LGPL-licensed: provide its editable Python source and the
    # application's build inputs alongside the license, so recipients can
    # modify the library and rebuild the combined program.
    import pystray
    library = Path(pystray.__file__).parent
    for source in library.rglob('*.py'):
        if '__pycache__' in source.parts:
            continue
        dest = DEST / 'pystray-source' / 'pystray' / source.relative_to(library)
        dest.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(source, dest)
    build_source = DEST / 'application-build-source'
    build_source.mkdir(parents=True, exist_ok=True)
    for name in ('app.py', 'audio_engine.py', 'profile_storage.py', 'self_test.py',
                 'single_instance.py', 'tray_control.py', 'voice_model.py',
                 'VoiceIsolation.spec', 'requirements.txt'):
        shutil.copy2(ROOT / name, build_source / name)
    (build_source / 'BUILD.txt').write_text(
        'Build with Python 3.12 and the pinned requirements plus PyInstaller 6.22.3. '
        'Copy the four ONNX files from the distributed _internal/models into a models '
        'directory beside the source, then run: pyinstaller --noconfirm VoiceIsolation.spec. '
        'pystray source and its LGPL license are in the neighboring pystray-source and '
        'pystray folders. Upstream: https://github.com/moses-palmer/pystray\n',
        encoding='utf-8')
    print(f'Collected third-party notices at {DEST}')


if __name__ == '__main__':
    main()
