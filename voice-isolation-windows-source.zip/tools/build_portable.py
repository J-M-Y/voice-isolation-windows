"""Build a clean, shareable Windows portable ZIP from the release staging tree."""
from pathlib import Path
import argparse
import hashlib
import zipfile


ROOT = Path(__file__).resolve().parent.parent
APP = ROOT / 'dist_release_final' / 'VoiceIsolation'
DRIVER = ROOT / 'downloads' / 'VBCABLE'
DRIVER_ZIP = ROOT / 'downloads' / 'VBCABLE_Driver_Pack46.zip'
MATERIALS = ROOT / 'release_materials'
OUTPUT = ROOT / 'release' / '人声提取-Windows-便携版.zip'
TOP = '人声提取-便携版'
PRIVATE_AUDIO = {'.wav', '.flac', '.mp3', '.ogg', '.m4a'}


def files_in(directory):
    return sorted(p for p in directory.rglob('*') if p.is_file())


def main(argv=None):
    parser = argparse.ArgumentParser(description='Build the self-contained Windows portable package')
    parser.add_argument('--source', type=Path, default=APP, help='Freshly built application directory')
    parser.add_argument('--output', type=Path, default=OUTPUT, help='ZIP output path')
    args = parser.parse_args(argv)
    app = args.source.resolve()
    output = args.output.resolve()
    if not (app / 'VoiceIsolation.exe').is_file() or not DRIVER_ZIP.is_file():
        raise SystemExit('Missing release application or original VB-CABLE package')
    app_files = files_in(app)
    if any(p.suffix.lower() in PRIVATE_AUDIO for p in app_files):
        raise SystemExit('Refusing to package: release staging contains an audio recording')
    if output == app or app in output.parents:
        raise SystemExit('ZIP output must be outside the application staging directory')
    output.parent.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(output, 'w', compression=zipfile.ZIP_DEFLATED,
                         compresslevel=6, allowZip64=True) as archive:
        for file in app_files:
            archive.write(file, str(Path(TOP) / file.relative_to(app)))
        archive.write(DRIVER_ZIP, str(Path(TOP) / 'VB-CABLE' / DRIVER_ZIP.name))
        for file in files_in(DRIVER):
            archive.write(file, str(Path(TOP) / 'VB-CABLE' / 'driver' / file.relative_to(DRIVER)))
        archive.write(MATERIALS / '使用说明.txt', str(Path(TOP) / '使用说明.txt'))
        licenses = MATERIALS / 'third_party'
        for file in files_in(licenses):
            archive.write(file, str(Path(TOP) / '第三方许可' / file.relative_to(licenses)))
    h = hashlib.sha256()
    with output.open('rb') as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b''):
            h.update(block)
    print(f'{output}\nsize={output.stat().st_size}\nsha256={h.hexdigest()}')


if __name__ == '__main__':
    main()
