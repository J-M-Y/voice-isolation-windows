﻿#ifndef AppSource
  #define AppSource "..\dist_release\VoiceIsolation"
#endif
#ifndef OutputFolder
  #define OutputFolder "..\release"
#endif
#ifndef ReleaseAppId
  #define ReleaseAppId "{{556D8951-7529-4D34-9A20-04CF2D3F6886}"
#endif
#ifndef RunningAppMutex
  #define RunningAppMutex "Local\VoiceIsolation_3E5B771A_Tray_v1.mutex"
#endif

#if !FileExists(AppSource + "\VoiceIsolation.exe")
  #error The release application is missing. Build dist_release\VoiceIsolation first.
#endif
#if FileExists(AppSource + "\_internal\我的声样.wav")
  #error Private voice sample detected in release input; remove it from the RELEASE STAGING DIRECTORY before packaging.
#endif

[Setup]
AppId={#ReleaseAppId}
AppName=人声提取
AppVersion=1.1.0
AppPublisher=Voice Isolation
DefaultDirName={localappdata}\Programs\VoiceIsolation
DefaultGroupName=人声提取
PrivilegesRequired=lowest
ArchitecturesAllowed=x64compatible
ArchitecturesInstallIn64BitMode=x64compatible
MinVersion=10.0
OutputDir={#OutputFolder}
OutputBaseFilename=人声提取-Windows-安装包
SetupLogging=yes
Compression=lzma2/fast
SolidCompression=yes
WizardStyle=modern
DisableProgramGroupPage=yes
UninstallDisplayIcon={app}\VoiceIsolation.exe
CloseApplications=no
RestartApplications=no
AppMutex={#RunningAppMutex}
InfoBeforeFile=installation-notice.txt

[Languages]
Name: "chinesesimp"; MessagesFile: "ChineseSimplified.isl"

[Messages]
SetupAppRunningError=检测到 %1 正在运行。%n%n请在屏幕右下角通知区域右键点击“人声提取”图标，选择“退出”；然后点击“确定”继续安装，或点击“取消”停止安装。
UninstallAppRunningError=检测到 %1 正在运行。%n%n请在屏幕右下角通知区域右键点击“人声提取”图标，选择“退出”；然后点击“确定”继续卸载，或点击“取消”停止卸载。

[Code]
function PrepareToInstall(var NeedsRestart: Boolean): String;
begin
  Result := '';
  { AppMutex is checked at setup startup; check again immediately before
    files are written, in case the user launched the application meanwhile. }
  while CheckForMutexes('{#RunningAppMutex}') do begin
    if WizardSilent then begin
      Result := '人声提取正在运行。请先从系统托盘选择“退出”，再重新安装。';
      Exit;
    end;
    if MsgBox('人声提取正在运行。请先在屏幕右下角的托盘菜单中选择“退出”，再点击“重试”。',
              mbError, MB_RETRYCANCEL) = IDCANCEL then begin
      Result := '安装已取消。请先退出人声提取后再试。';
      Exit;
    end;
  end;
end;

[Tasks]
Name: "desktopicon"; Description: "创建桌面快捷方式"; GroupDescription: "快捷方式："

[Files]
Source: "{#AppSource}\*"; DestDir: "{app}"; Flags: ignoreversion recursesubdirs createallsubdirs; Excludes: "*.wav,*.flac,*.mp3,*.ogg,*.m4a"
Source: "..\downloads\VBCABLE_Driver_Pack46.zip"; DestDir: "{app}\VB-CABLE"; Flags: ignoreversion
Source: "..\downloads\VBCABLE\*"; DestDir: "{app}\VB-CABLE\driver"; Flags: ignoreversion recursesubdirs createallsubdirs
Source: "..\release_materials\使用说明.txt"; DestDir: "{app}"; Flags: ignoreversion
Source: "..\release_materials\third_party\*"; DestDir: "{app}\第三方许可"; Flags: ignoreversion recursesubdirs createallsubdirs

[Icons]
Name: "{group}\人声提取"; Filename: "{app}\VoiceIsolation.exe"; WorkingDir: "{app}"
Name: "{autodesktop}\人声提取"; Filename: "{app}\VoiceIsolation.exe"; WorkingDir: "{app}"; Tasks: desktopicon
Name: "{group}\VB-CABLE 驱动安装程序"; Filename: "{app}\VB-CABLE\driver\VBCABLE_Setup_x64.exe"; WorkingDir: "{app}\VB-CABLE\driver"
Name: "{group}\使用说明"; Filename: "{app}\使用说明.txt"

[Run]
Filename: "{app}\VB-CABLE\driver\VBCABLE_Setup_x64.exe"; Description: "首次使用且电脑未安装 VB-CABLE 时，勾选打开虚拟声卡安装程序（需要管理员权限）"; Verb: "runas"; Flags: postinstall shellexec skipifsilent unchecked
Filename: "{app}\VoiceIsolation.exe"; Description: "启动人声提取"; Flags: nowait postinstall skipifsilent
