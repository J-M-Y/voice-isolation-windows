param(
    [string]$AppSource = (Join-Path $PSScriptRoot '..\dist_release\VoiceIsolation'),
    [string]$OutputFolder = (Join-Path $PSScriptRoot '..\release'),
    [switch]$SmokeTest
)

$ErrorActionPreference = 'Stop'
$projectRoot = Split-Path -Parent $PSScriptRoot
$compiler = Join-Path $projectRoot 'buildtools\InnoSetup\ISCC.exe'
if (-not (Test-Path -LiteralPath $compiler -PathType Leaf)) {
    throw 'Inno Setup compiler not found in buildtools\InnoSetup. Install the official compiler or update this path.'
}
$appSourceAbsolute = (Resolve-Path -LiteralPath $AppSource).Path
if (-not (Test-Path -LiteralPath (Join-Path $appSourceAbsolute 'VoiceIsolation.exe') -PathType Leaf)) {
    throw 'Release application not found. Build dist_release\VoiceIsolation first.'
}
$privateAudio = Get-ChildItem -LiteralPath $appSourceAbsolute -Recurse -File |
    Where-Object { $_.Extension -in '.wav', '.flac', '.mp3', '.ogg', '.m4a' } |
    Select-Object -First 1
if ($privateAudio) {
    throw 'Release staging contains an audio recording. Remove personal recordings from the RELEASE STAGING COPY before packaging.'
}
New-Item -ItemType Directory -Path $OutputFolder -Force | Out-Null
$outputAbsolute = (Resolve-Path -LiteralPath $OutputFolder).Path
$projectRoot = (Resolve-Path -LiteralPath $projectRoot).Path
Push-Location $PSScriptRoot
try {
    $compilerArguments = @("/DAppSource=$appSourceAbsolute", "/DOutputFolder=$outputAbsolute")
    if ($SmokeTest) { $compilerArguments += '/DReleaseAppId={{F33945B3-99AB-4433-AFB0-C95547DDAE96}' }
    & $compiler @compilerArguments 'VoiceIsolation.iss'
    if ($LASTEXITCODE -ne 0) { throw "Inno Setup failed with exit code $LASTEXITCODE" }
} finally {
    Pop-Location
}
