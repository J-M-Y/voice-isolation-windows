# Windows 安装包构建说明

在项目根目录，以 Windows PowerShell 运行 `installer\build_installer.ps1`。默认输入为 `dist_release\VoiceIsolation`，输出为 `release\人声提取-Windows-安装包.exe`。输入目录应当是从当前源码全新构建的 PyInstaller onedir；保留 `_internal` 和 `models`，不要使用包含个人声样的运行目录作为输入。

构建脚本会拒绝输入目录中的 WAV、FLAC、MP3、OGG 或 M4A 音频文件，并且安装器也会排除这些文件。这是为了避免将测试录音或个人声样分发给其他人。安装器不会捆绑用户原有的声样。程序在用户首次使用时单独录入声音。

默认构建器路径为 `buildtools\InnoSetup\ISCC.exe`。本次构建使用原厂 Inno Setup 6.7.3 及 Inno 官网列出的简体中文翻译。当前编译器显示“Non-commercial use only”；Inno 网站请求商业用户购买许可，其随附许可证文本允许包括商业应用在内的使用。如需商业使用，请核对当前原厂条款。压缩包和原样展开的 VB-CABLE 文件由 `downloads` 目录提供；分发需保留 VB-Audio 的署名、官网和 donationware 提示，已经写入安装说明。卸载主程序不会卸载 VB-CABLE。

可用 `-AppSource` 和 `-OutputFolder` 参数指定临时目录。`-SmokeTest` 会使用独立测试应用标识，不覆盖正式安装的注册信息；它仅用于测试安装和卸载，不用于正式发布。
