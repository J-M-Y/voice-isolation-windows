"""WASAPI must support devices whose configured format differs from 48 kHz."""
import unittest
from unittest import mock

import numpy as np

import audio_engine


class CompatibleAudioSettingsTests(unittest.TestCase):
    def test_wasapi_uses_shared_format_conversion(self):
        marker = object()
        with mock.patch.object(audio_engine.sys, "platform", "win32"), \
             mock.patch.object(audio_engine.sd, "query_devices", return_value={"hostapi": 3}), \
             mock.patch.object(audio_engine.sd, "query_hostapis", return_value={"name": "Windows WASAPI"}), \
             mock.patch.object(audio_engine.sd, "WasapiSettings", return_value=marker) as settings:
            self.assertIs(audio_engine.compatible_audio_settings(22), marker)
        settings.assert_called_once_with(auto_convert=True)

    def test_other_audio_apis_do_not_receive_wasapi_settings(self):
        with mock.patch.object(audio_engine.sys, "platform", "win32"), \
             mock.patch.object(audio_engine.sd, "query_devices", return_value={"hostapi": 1}), \
             mock.patch.object(audio_engine.sd, "query_hostapis", return_value={"name": "Windows DirectSound"}), \
             mock.patch.object(audio_engine.sd, "WasapiSettings") as settings:
            self.assertIsNone(audio_engine.compatible_audio_settings(2))
        settings.assert_not_called()

    def test_non_windows_does_not_query_audio_host(self):
        with mock.patch.object(audio_engine.sys, "platform", "linux"), \
             mock.patch.object(audio_engine.sd, "query_devices") as query:
            self.assertIsNone(audio_engine.compatible_audio_settings(2))
        query.assert_not_called()

    def test_streams_use_their_own_settings_for_checks_and_creation(self):
        input_settings, output_settings = object(), object()
        mic, output, processor = mock.Mock(), mock.Mock(), mock.Mock()
        engine = audio_engine.AudioEngine(1, 2, processor)
        with mock.patch.object(audio_engine, "compatible_audio_settings", side_effect=[input_settings, output_settings]), \
             mock.patch.object(audio_engine.sd, "check_input_settings") as check_input, \
             mock.patch.object(audio_engine.sd, "check_output_settings") as check_output, \
             mock.patch.object(audio_engine.sd, "InputStream", return_value=mic) as input_stream, \
             mock.patch.object(audio_engine.sd, "OutputStream", return_value=output) as output_stream:
            engine.start()
            engine.stop()
        self.assertIs(check_input.call_args.kwargs["extra_settings"], input_settings)
        self.assertIs(check_output.call_args.kwargs["extra_settings"], output_settings)
        self.assertIs(input_stream.call_args.kwargs["extra_settings"], input_settings)
        self.assertIs(output_stream.call_args.kwargs["extra_settings"], output_settings)

    def test_reference_recording_uses_device_settings(self):
        marker = object()
        # Invalid silence intentionally stops before writing a reference file.
        with mock.patch.object(audio_engine, "compatible_audio_settings", return_value=marker), \
             mock.patch.object(audio_engine.sd, "rec", return_value=np.zeros((10, 1), dtype=np.float32)) as rec:
            with self.assertRaises(ValueError):
                audio_engine.record_reference(1, 48000, 1, "unused.wav")
        self.assertIs(rec.call_args.kwargs["extra_settings"], marker)


if __name__ == "__main__":
    unittest.main()
