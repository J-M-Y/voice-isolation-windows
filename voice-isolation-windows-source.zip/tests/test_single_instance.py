import os
import subprocess
import sys
import threading
import unittest
import uuid

from single_instance import WindowsInstance


@unittest.skipUnless(os.name == 'nt', 'Windows named kernel objects required')
class SingleInstanceTests(unittest.TestCase):
    def setUp(self):
        self.name = 'Local\\VoiceIsolationTest_' + uuid.uuid4().hex

    def test_second_process_signals_first_and_exits(self):
        first = WindowsInstance(self.name)
        try:
            self.assertTrue(first.acquire())
            command = (
                'import sys; from single_instance import WindowsInstance; '
                'g=WindowsInstance(sys.argv[1]); '
                'primary=g.acquire(); g.close(); '
                'sys.exit(9 if primary else 0)'
            )
            result = subprocess.run([sys.executable, '-c', command, self.name], timeout=10)
            self.assertEqual(result.returncode, 0)
            self.assertTrue(first._show.wait(3))
            self.assertTrue(first.take_show_request())
            self.assertFalse(first.take_show_request())
        finally:
            first.close()

        replacement = WindowsInstance(self.name)
        try:
            self.assertTrue(replacement.acquire())
        finally:
            replacement.close()

    def test_simultaneous_start_has_one_primary(self):
        barrier = threading.Barrier(2)
        guards = [WindowsInstance(self.name), WindowsInstance(self.name)]
        results = [None, None]
        errors = []

        def acquire(index):
            try:
                barrier.wait(timeout=5)
                results[index] = guards[index].acquire()
            except Exception as exc:
                errors.append(exc)

        threads = [threading.Thread(target=acquire, args=(i,)) for i in range(2)]
        try:
            for thread in threads:
                thread.start()
            for thread in threads:
                thread.join(timeout=10)
            self.assertFalse(errors)
            self.assertEqual(sorted(results), [False, True])
            primary = guards[results.index(True)]
            self.assertTrue(primary._show.wait(3))
            self.assertTrue(primary.take_show_request())
        finally:
            for guard in guards:
                guard.close()
