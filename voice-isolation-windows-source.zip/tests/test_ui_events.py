"""A late callback from a stopped session must not affect a new session."""
import queue
import unittest
from unittest import mock

import app


class UiEventTests(unittest.TestCase):
    def make_app(self):
        instance = app.VoiceApp.__new__(app.VoiceApp)
        instance.events = queue.Queue()
        instance.root = mock.Mock()
        instance.status_var = mock.Mock()
        instance.busy = False
        instance.engine = None
        instance.pending_stream_error = None
        instance.run_generation = 2
        instance.closing = False
        return instance

    def test_late_old_stream_error_is_ignored(self):
        instance = self.make_app()
        instance.events.put(("stream_error", (1, "old error")))
        with mock.patch.object(app.messagebox, "showerror") as error:
            instance.poll()
        error.assert_not_called()
        self.assertIsNone(instance.pending_stream_error)

    def test_failed_start_discards_error_received_during_start(self):
        instance = self.make_app()
        instance.busy = True
        instance.events.put(("stream_error", (2, "stream error")))
        instance.events.put(("start_failed", (2, "startup failed")))
        with mock.patch.object(app.messagebox, "showerror") as error:
            instance.poll()
        error.assert_called_once_with("操作失败", "startup failed")
        self.assertIsNone(instance.pending_stream_error)
        self.assertFalse(instance.busy)


if __name__ == "__main__":
    unittest.main()
