"""COM lifetime for audio called from Python worker threads."""
import ctypes
import unittest
from unittest import mock

import audio_engine


class ComAudioTests(unittest.TestCase):
    def run_context(self, result, *, throws=False):
        ole = mock.Mock()
        ole.CoInitializeEx.return_value = result
        with mock.patch.object(audio_engine.sys, 'platform', 'win32'), \
             mock.patch.object(ctypes, 'windll', mock.Mock(ole32=ole), create=True):
            if throws:
                with self.assertRaisesRegex(RuntimeError, 'inside'):
                    with audio_engine.com_initialized():
                        raise RuntimeError('inside')
            else:
                with audio_engine.com_initialized():
                    pass
        return ole

    def test_success_and_already_initialized_are_balanced(self):
        for result in (0, 1):
            with self.subTest(result=result):
                ole = self.run_context(result, throws=True)
                ole.CoInitializeEx.assert_called_once_with(None, 0)
                ole.CoUninitialize.assert_called_once_with()

    def test_existing_other_apartment_is_not_uninitialized(self):
        ole = self.run_context(-2147417850)
        ole.CoUninitialize.assert_not_called()

    def test_other_failure_is_reported_without_uninitializing(self):
        ole = mock.Mock()
        ole.CoInitializeEx.return_value = -2147467259
        with mock.patch.object(audio_engine.sys, 'platform', 'win32'), \
             mock.patch.object(ctypes, 'windll', mock.Mock(ole32=ole), create=True):
            with self.assertRaisesRegex(OSError, '80004005'):
                with audio_engine.com_initialized():
                    self.fail('must not enter on failure')
        ole.CoUninitialize.assert_not_called()


if __name__ == '__main__':
    unittest.main()
