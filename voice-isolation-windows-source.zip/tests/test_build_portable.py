from pathlib import Path
from tempfile import TemporaryDirectory
from unittest import TestCase
from unittest.mock import patch
import zipfile

from tools import build_portable as build


class PortableBuildTests(TestCase):
    def setUp(self):
        self.temp = TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.root = Path(self.temp.name)
        self.app = self.root / 'clean-app'
        self.app.mkdir()
        (self.app / 'VoiceIsolation.exe').write_bytes(b'app')
        self.driver = self.root / 'driver'
        self.driver.mkdir()
        (self.driver / 'VBCABLE_Setup_x64.exe').write_bytes(b'driver')
        self.vendor_zip = self.root / 'original.zip'
        self.vendor_zip.write_bytes(b'original package')
        self.materials = self.root / 'materials'
        (self.materials / 'third_party').mkdir(parents=True)
        (self.materials / 'third_party' / 'license.txt').write_text('license')
        (self.materials / '使用说明.txt').write_text('guide', encoding='utf-8')
        self.output = self.root / 'out' / 'portable.zip'

        for name, value in (('DRIVER', self.driver), ('DRIVER_ZIP', self.vendor_zip),
                            ('MATERIALS', self.materials)):
            p = patch.object(build, name, value)
            p.start()
            self.addCleanup(p.stop)

    def test_selected_fresh_build_and_vendor_files_are_packaged(self):
        build.main(['--source', str(self.app), '--output', str(self.output)])
        with zipfile.ZipFile(self.output) as archive:
            names = set(archive.namelist())
        self.assertIn('人声提取-便携版/VoiceIsolation.exe', names)
        self.assertIn('人声提取-便携版/VB-CABLE/driver/VBCABLE_Setup_x64.exe', names)
        self.assertIn('人声提取-便携版/VB-CABLE/original.zip', names)
        self.assertIn('人声提取-便携版/使用说明.txt', names)

    def test_refuses_to_package_voice_recording(self):
        (self.app / '我的声样.wav').write_bytes(b'private')
        with self.assertRaises(SystemExit):
            build.main(['--source', str(self.app), '--output', str(self.output)])
        self.assertFalse(self.output.exists())

    def test_refuses_output_inside_input_tree(self):
        with self.assertRaises(SystemExit):
            build.main(['--source', str(self.app), '--output', str(self.app / 'self.zip')])
