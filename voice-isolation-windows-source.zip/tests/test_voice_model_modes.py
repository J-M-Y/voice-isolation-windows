"""Exercise model routing and variable-length streaming without audio devices."""
import unittest
from types import SimpleNamespace
from unittest.mock import patch
import numpy as np
from voice_model import VoiceProcessor


class StreamTests(unittest.TestCase):
    def test_selected_mode_chooses_expected_model(self):
        chosen = []

        def create_denoiser(config):
            chosen.append((config.model.gtcrn.model, config.model.dpdfnet.model))
            return SimpleNamespace(sample_rate=16000, frame_shift_in_samples=160)

        with patch('voice_model.voxlock.load_audio', return_value=np.ones(48000, dtype=np.float32)), \
             patch('voice_model.voxlock.VoxLock') as voxlock, \
             patch('voice_model.sherpa_onnx.OnlineSpeechDenoiser', side_effect=create_denoiser):
            voxlock.return_value.stream.return_value = object()
            VoiceProcessor('unused.wav', 48000, 3840, strong_music=False)
            VoiceProcessor('unused.wav', 48000, 3840, strong_music=True)
        self.assertTrue(chosen[0][0].endswith('gtcrn_simple.onnx'))
        self.assertFalse(chosen[0][1])
        self.assertFalse(chosen[1][0])
        self.assertTrue(chosen[1][1].endswith('dpdfnet2.onnx'))

    def test_both_modes_extract_before_denoising(self):
        processor = VoiceProcessor.__new__(VoiceProcessor)
        order = []
        processor._extract = lambda x: (order.append('extract') or (x + 1))
        processor._denoise = lambda x: (order.append('denoise') or (x * 2))
        x = np.array([2], dtype=np.float32)
        processor.strong_music = False
        self.assertEqual(processor._process_16k(x)[0], 6)
        self.assertEqual(order, ['extract', 'denoise'])
        order.clear()
        processor.strong_music = True
        self.assertEqual(processor._process_16k(x)[0], 6)
        self.assertEqual(order, ['extract', 'denoise'])

    def test_short_denoiser_output_is_delayed_not_dropped(self):
        processor = VoiceProcessor.__new__(VoiceProcessor)
        processor.denoise_queue = np.array([], dtype=np.float32)
        outputs = iter([np.array([1, 2], dtype=np.float32),
                        np.array([3, 4, 5, 6], dtype=np.float32)])
        processor.denoiser = lambda data, sample_rate: SimpleNamespace(samples=next(outputs))
        x = np.zeros(4, dtype=np.float32)
        np.testing.assert_array_equal(processor._denoise(x), [0, 0, 1, 2])
        np.testing.assert_array_equal(processor._denoise(x), [3, 4, 5, 6])

    def test_short_extractor_output_is_delayed_not_dropped(self):
        processor = VoiceProcessor.__new__(VoiceProcessor)
        processor.queue = np.array([], dtype=np.float32)
        outputs = iter([np.array([1, 2], dtype=np.float32),
                        np.array([3, 4, 5, 6], dtype=np.float32)])
        processor.stream = SimpleNamespace(push=lambda data: next(outputs))
        x = np.zeros(4, dtype=np.float32)
        np.testing.assert_array_equal(processor._extract(x), [0, 0, 1, 2])
        np.testing.assert_array_equal(processor._extract(x), [3, 4, 5, 6])


if __name__ == '__main__':
    unittest.main()
