import unittest

import numpy as np

from app import BLOCK, process_comparison


class HalfVolumeProcessor:
    def __init__(self):
        self.calls = []

    def process(self, block):
        self.calls.append(np.array(block, copy=True))
        return block / 2


class ComparisonTests(unittest.TestCase):
    def test_preserves_length_and_relative_volume_on_partial_final_block(self):
        raw = np.linspace(-0.8, 0.8, BLOCK + 37, dtype=np.float32)
        processor = HalfVolumeProcessor()
        filtered = process_comparison(raw, processor)
        np.testing.assert_allclose(filtered, raw / 2)
        self.assertEqual(len(processor.calls), 2)
        np.testing.assert_array_equal(processor.calls[-1][37:], 0)

    def test_rejects_invalid_model_output(self):
        class Invalid:
            def process(self, block):
                return np.full(BLOCK, np.nan, dtype=np.float32)

        with self.assertRaisesRegex(ValueError, '无效'):
            process_comparison(np.ones(BLOCK, dtype=np.float32), Invalid())
