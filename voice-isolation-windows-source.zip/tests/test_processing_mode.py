import queue
import tempfile
import unittest
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import MagicMock, patch

import numpy as np

from app import VoiceApp, RATE, BLOCK


class Value:
    def __init__(self, value):
        self.value = value

    def get(self):
        return self.value

    def set(self, value):
        self.value = value


class ProcessingModeTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.reference = Path(self.temp.name) / 'sample.wav'
        self.reference.touch()
        self.app = VoiceApp.__new__(VoiceApp)
        self.app.busy = False
        self.app.engine = None
        self.app.run_generation = 0
        self.app.pending_stream_error = None
        self.app.selected_input = lambda: 12
        self.app.outputs = {'cable': 21}
        self.app.output_var = Value('cable')
        self.app.reference_var = Value(str(self.reference))
        self.app.strong_music_var = Value(True)
        self.app.status_var = Value('')
        self.app.comparison_status = Value('')
        self.app.raw_button = MagicMock()
        self.app.processed_button = MagicMock()
        self.app.events = queue.Queue()
        self.deferred = []

    def thread(self, *, target, daemon):
        return SimpleNamespace(start=lambda: self.deferred.append(target))

    def test_realtime_captures_selected_mode_at_start(self):
        processor = MagicMock()
        with patch('app.threading.Thread', side_effect=self.thread), \
             patch('app.voice_model.create_processor', return_value=processor) as create, \
             patch('app.AudioEngine'):
            self.app.start()
            self.app.strong_music_var.set(False)
            self.deferred.pop()()
            create.assert_called_once_with(str(self.reference), RATE, BLOCK, strong_music=True)

    def test_comparison_captures_selected_mode_at_record(self):
        processor = MagicMock()
        processor.process.side_effect = lambda block: block
        with patch('app.threading.Thread', side_effect=self.thread), \
             patch('app.voice_model.create_processor', return_value=processor) as create, \
             patch('app.sd.rec', return_value=np.zeros((5 * RATE, 1), dtype=np.float32)):
            self.app.record_comparison()
            self.app.strong_music_var.set(False)
            self.deferred.pop()()
            create.assert_called_once_with(str(self.reference), RATE, BLOCK, strong_music=True)
            self.assertEqual(self.app.events.get_nowait()[0], 'comparison_ready')
