"""Microphone level feedback is advisory, including near the boundaries."""
from unittest import TestCase

from app import microphone_test_message


class MicrophoneAdviceTests(TestCase):
    def test_no_or_very_low_signal_suggests_checking_device(self):
        self.assertIn('没有检测到', microphone_test_message('测试', 0.000999))

    def test_quiet_speech_is_not_rejected(self):
        for level in (0.001, 0.005, 0.009999):
            with self.subTest(level=level):
                advice = microphone_test_message('测试', level)
                self.assertIn('音量偏小', advice)
                self.assertIn('仍然可以继续录音', advice)

    def test_normal_level_is_accepted_including_boundary(self):
        self.assertIn('可以用来录入', microphone_test_message('测试', 0.01))
        self.assertIn('可以用来录入', microphone_test_message('测试', 0.08))
