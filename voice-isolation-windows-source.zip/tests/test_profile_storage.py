import os
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch

from profile_storage import prepare_reference, reference_path


class ProfileStorageTests(unittest.TestCase):
    def test_reference_lives_under_current_users_local_appdata(self):
        with tempfile.TemporaryDirectory() as folder:
            with patch.dict(os.environ, {"LOCALAPPDATA": folder}):
                self.assertEqual(reference_path(), Path(folder) / "VoiceIsolation" / "我的声样.wav")

    def test_old_adjacent_reference_is_copied_without_deletion(self):
        with tempfile.TemporaryDirectory() as folder:
            root = Path(folder)
            old = root / 'old' / '我的声样.wav'
            old.parent.mkdir()
            old.write_bytes(b'legacy recording')
            destination = root / 'profile' / '我的声样.wav'
            self.assertTrue(prepare_reference(destination, [old]))
            self.assertEqual(destination.read_bytes(), b'legacy recording')
            self.assertEqual(old.read_bytes(), b'legacy recording')

    def test_existing_user_reference_is_never_overwritten(self):
        with tempfile.TemporaryDirectory() as folder:
            root = Path(folder)
            old, destination = root / 'old.wav', root / 'profile' / '我的声样.wav'
            old.write_bytes(b'old')
            destination.parent.mkdir()
            destination.write_bytes(b'new')
            self.assertFalse(prepare_reference(destination, [old]))
            self.assertEqual(destination.read_bytes(), b'new')

    def test_first_run_without_profile_does_not_create_recording(self):
        with tempfile.TemporaryDirectory() as folder:
            destination = Path(folder) / 'profile' / '我的声样.wav'
            self.assertFalse(prepare_reference(destination, [Path(folder) / 'missing.wav']))
            self.assertTrue(destination.parent.is_dir())
            self.assertFalse(destination.exists())


if __name__ == '__main__':
    unittest.main()
