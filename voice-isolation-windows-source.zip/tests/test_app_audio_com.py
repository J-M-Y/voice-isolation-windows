"""The GUI's audio workers must initialize COM on their own threads."""
from contextlib import contextmanager
from pathlib import Path
from types import SimpleNamespace
from unittest import TestCase
from unittest.mock import MagicMock, patch
import queue
import tempfile

import numpy as np

import app


class Value:
    def __init__(self, value):
        self.value = value

    def get(self):
        return self.value

    def set(self, value):
        self.value = value


class AudioWorkerComTests(TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.reference = Path(self.temp.name) / 'reference.wav'
        self.reference.write_bytes(b'old sample')
        self.app = app.VoiceApp.__new__(app.VoiceApp)
        self.app.busy = False
        self.app.engine = None
        self.app.selected_input = lambda: 7
        self.app.input_var = Value('microphone')
        self.app.reference_var = Value(str(self.reference))
        self.app.strong_music_var = Value(False)
        self.app.status_var = Value('')
        self.app.comparison_status = Value('')
        self.app.raw_button = MagicMock()
        self.app.processed_button = MagicMock()
        self.app.comparison_output_var = Value('headphones')
        self.app.comparison_outputs = {'headphones': 8}
        self.app.comparison_raw = np.zeros(20, dtype=np.float32)
        self.app.comparison_processed = np.zeros(20, dtype=np.float32)
        self.app.outputs = {'cable': 21}
        self.app.output_var = Value('cable')
        self.app.run_generation = 0
        self.app.pending_stream_error = None
        self.app.events = queue.Queue()
        self.deferred = []
        self.in_com = False
        # The test uses synthetic device indexes, not the host PC's devices.
        settings_patch = patch('app.compatible_audio_settings', return_value=None)
        self.settings = settings_patch.start()
        self.addCleanup(settings_patch.stop)

    @contextmanager
    def com_scope(self):
        self.assertFalse(self.in_com)
        self.in_com = True
        try:
            yield
        finally:
            self.in_com = False

    def thread(self, *, target, daemon):
        return SimpleNamespace(start=lambda: self.deferred.append(target))

    def require_com(self, *args, **kwargs):
        self.assertTrue(self.in_com, 'audio API was called outside COM context')
        return np.full((args[0], 1), 0.01, dtype=np.float32)

    def test_microphone_test_initializes_com(self):
        with patch('app.threading.Thread', side_effect=self.thread), \
             patch('app.com_initialized', self.com_scope), \
             patch('app.sd.rec', side_effect=self.require_com):
            self.app.test_microphone()
            self.deferred.pop()()
        self.assertEqual(self.app.events.get_nowait()[0], 'mic_test')
        self.settings.assert_called_once_with(7)
        self.assertFalse(self.in_com)

    def test_enrollment_recording_initializes_com(self):
        def record(device, rate, seconds, path):
            self.assertTrue(self.in_com)
            path.write_bytes(b'new sample')

        with patch('app.threading.Thread', side_effect=self.thread), \
             patch('app.com_initialized', self.com_scope), \
             patch('app.record_reference', side_effect=record), \
             patch('app.REFERENCE', self.reference):
            self.app.record()
            self.deferred.pop()()
        self.assertEqual(self.app.events.get_nowait()[0], 'recorded')
        self.assertEqual(self.reference.read_bytes(), b'new sample')
        self.assertFalse(self.in_com)

    def test_comparison_recording_initializes_com(self):
        processor = MagicMock()
        processor.process.side_effect = lambda block: block
        with patch('app.threading.Thread', side_effect=self.thread), \
             patch('app.com_initialized', self.com_scope), \
             patch('app.sd.rec', side_effect=self.require_com), \
             patch('app.voice_model.create_processor', return_value=processor):
            self.app.record_comparison()
            self.deferred.pop()()
        self.assertEqual(self.app.events.get_nowait()[0], 'comparison_ready')
        self.settings.assert_called_once_with(7)
        self.assertFalse(self.in_com)

    def test_comparison_playback_initializes_com(self):
        def play(*args, **kwargs):
            self.assertTrue(self.in_com)

        with patch('app.threading.Thread', side_effect=self.thread), \
             patch('app.com_initialized', self.com_scope), \
             patch('app.sd.play', side_effect=play):
            self.app.play_comparison(True)
            self.deferred.pop()()
        self.assertEqual(self.app.events.get_nowait()[0], 'comparison_played')
        self.settings.assert_called_once_with(8)
        self.assertFalse(self.in_com)

    def test_realtime_start_initializes_com(self):
        engine = MagicMock()
        engine.start.side_effect = lambda: self.assertTrue(self.in_com)
        with patch('app.threading.Thread', side_effect=self.thread), \
             patch('app.com_initialized', self.com_scope), \
             patch('app.voice_model.create_processor'), \
             patch('app.AudioEngine', return_value=engine):
            self.app.start()
            self.deferred.pop()()
        engine.start.assert_called_once()
        self.assertEqual(self.app.events.get_nowait()[0], 'started')
        self.assertFalse(self.in_com)
