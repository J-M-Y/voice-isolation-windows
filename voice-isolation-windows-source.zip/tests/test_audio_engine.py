"""Regression checks for recording validation and failed audio startup."""
import tempfile
import unittest
from pathlib import Path
from unittest import mock

import numpy as np

import audio_engine


class AudioEngineTests(unittest.TestCase):
    def test_silent_recording_does_not_overwrite_previous_sample(self):
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "sample.wav"
            path.write_bytes(b"previous sample")
            with mock.patch.object(audio_engine.sd, "rec", return_value=np.zeros((4800, 1), dtype=np.float32)):
                with self.assertRaisesRegex(ValueError, "音量过低"):
                    audio_engine.record_reference(0, 48000, 0.1, path)
            self.assertEqual(path.read_bytes(), b"previous sample")

    def test_start_failure_closes_both_streams_and_processor(self):
        processor = mock.Mock()
        mic = mock.Mock()
        output = mock.Mock()
        mic.start.side_effect = RuntimeError("input device failed")
        mic.stop.side_effect = RuntimeError("not started")
        engine = audio_engine.AudioEngine(0, 1, processor)
        with mock.patch.object(audio_engine.sd, "check_input_settings"), \
             mock.patch.object(audio_engine.sd, "check_output_settings"), \
             mock.patch.object(audio_engine.sd, "InputStream", return_value=mic), \
             mock.patch.object(audio_engine.sd, "OutputStream", return_value=output):
            with self.assertRaisesRegex(RuntimeError, "input device failed"):
                engine.start()
        mic.close.assert_called_once()
        output.stop.assert_called_once()
        output.close.assert_called_once()
        processor.close.assert_called_once()
        self.assertFalse(engine.worker.is_alive())

    def test_device_validation_failure_releases_processor(self):
        processor = mock.Mock()
        engine = audio_engine.AudioEngine(0, 1, processor)
        with mock.patch.object(audio_engine.sd, "check_input_settings", side_effect=ValueError("invalid input")):
            with self.assertRaisesRegex(ValueError, "invalid input"):
                engine.start()
        processor.close.assert_called_once()


if __name__ == "__main__":
    unittest.main()
