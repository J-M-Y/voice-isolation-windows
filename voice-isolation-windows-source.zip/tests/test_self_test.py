import json
from pathlib import Path
import tempfile
from unittest import TestCase
from unittest.mock import patch

import numpy as np

import self_test


class SelfTestTests(TestCase):
    def test_explicit_reference_exercises_both_modes_and_writes_json(self):
        class Processor:
            def process(self, block):
                return block * 0.5
            def close(self):
                pass

        with tempfile.TemporaryDirectory() as directory:
            output = Path(directory) / 'result.json'
            modes = []

            def create(path, rate, block, strong_music):
                modes.append(strong_music)
                return Processor()

            with patch('self_test.voice_model.voxlock.load_audio', return_value=np.ones(48000, dtype=np.float32)), \
                 patch('self_test.voice_model.create_processor', side_effect=create):
                code = self_test.run_self_test('explicit-test.wav', output)
            result = json.loads(output.read_text(encoding='utf-8'))
            self.assertEqual(code, 0)
            self.assertTrue(result['ok'])
            self.assertEqual(modes, [False, True])
            self.assertEqual(set(result['modes']), {'normal', 'strong'})

    def test_bad_reference_reports_failure_without_a_window(self):
        with tempfile.TemporaryDirectory() as directory:
            output = Path(directory) / 'result.json'
            with patch('self_test.voice_model.voxlock.load_audio', side_effect=FileNotFoundError('missing')):
                code = self_test.run_self_test('missing.wav', output)
            result = json.loads(output.read_text(encoding='utf-8'))
            self.assertEqual(code, 1)
            self.assertFalse(result['ok'])
            self.assertIn('FileNotFoundError', result['error'])
