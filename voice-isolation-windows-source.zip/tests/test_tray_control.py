import queue
import threading
import time
import unittest

from tray_control import TrayController


class FakeIcon:
    def __init__(self, show, quit_app, failed, fail_visible=False):
        self.show, self.quit_app, self.failed = show, quit_app, failed
        self.fail_visible = fail_visible
        self.done = threading.Event()
        self._visible = False

    @property
    def visible(self):
        return self._visible

    @visible.setter
    def visible(self, value):
        if self.fail_visible:
            raise OSError('tray not available')
        self._visible = value

    def run(self, setup):
        setup(self)
        self.done.wait(3)

    def stop(self):
        self.done.set()

    def _mark_ready(self):
        pass


class TrayControllerTests(unittest.TestCase):
    def setUp(self):
        self.events = queue.Queue()
        self.made = []

    def factory(self, show, quit_app, failed):
        icon = FakeIcon(show, quit_app, failed)
        self.made.append(icon)
        return icon

    def test_show_and_exit_are_queued_and_stop_cleans_up(self):
        controller = TrayController(self.events, self.factory)
        try:
            self.assertTrue(controller.start())
            self.assertTrue(controller.available)
            self.made[0].show()
            self.made[0].quit_app()
            self.assertEqual(self.events.get_nowait(), ('tray_show', None))
            self.assertEqual(self.events.get_nowait(), ('tray_exit', None))
        finally:
            controller.stop()
        self.assertFalse(controller.available)
        self.assertFalse(controller._thread.is_alive())
        self.assertTrue(self.events.empty())

    def test_registration_failure_never_claims_icon_is_available(self):
        controller = TrayController(self.events,
            lambda show, quit_app, failed: FakeIcon(show, quit_app, failed, fail_visible=True))
        self.assertFalse(controller.start())
        self.assertFalse(controller.available)
        self.assertIn('tray not available', controller.error)
        self.assertFalse(controller._thread.is_alive())

    def test_loop_failure_after_start_posts_recovery_event(self):
        controller = TrayController(self.events, self.factory)
        self.assertTrue(controller.start())
        self.made[0].done.set()
        controller._thread.join(2)
        self.assertEqual(self.events.get_nowait()[0], 'tray_failed')
        self.assertFalse(controller.available)

    def test_explorer_registration_failure_requests_window_recovery(self):
        controller = TrayController(self.events, self.factory)
        try:
            self.assertTrue(controller.start())
            self.made[0].failed('registration failed')
            self.assertEqual(self.events.get_nowait(), ('tray_failed', 'registration failed'))
            self.assertFalse(controller.available)
        finally:
            controller.stop()

    def test_hover_text_reflects_running_state(self):
        controller = TrayController(self.events, self.factory)
        controller.set_running(True)
        try:
            self.assertTrue(controller.start())
            self.assertIn('正在过滤', self.made[0].title)
            controller.set_running(False)
            self.assertIn('已停止', self.made[0].title)
        finally:
            controller.stop()

    def test_hover_update_failure_does_not_break_audio(self):
        class BrokenTitle:
            @property
            def title(self):
                return ''

            @title.setter
            def title(self, value):
                raise OSError('shell unavailable')

        controller = TrayController(self.events, self.factory)
        controller._icon = BrokenTitle()
        controller.set_running(True)
        self.assertTrue(controller._processing)


if __name__ == '__main__':
    unittest.main()
