import unittest

from app import device_choices


class DeviceChoicesTests(unittest.TestCase):
    def test_wasapi_hides_duplicate_backends_and_virtual_input(self):
        hosts = [{'name': 'MME'}, {'name': 'Windows WASAPI'}]
        def device(name, host, ins=0, outs=0):
            return {'name': name, 'hostapi': host, 'max_input_channels': ins,
                    'max_output_channels': outs}
        devices = [device('麦克风 (Web Camera)', 0, 2),
                   device('麦克风 (Realtek(R) Audio)', 0, 2),
                   device('麦克风 (Web Camera)', 1, 2),
                   device('麦克风 (Realtek(R) Audio)', 1, 2),
                   device('CABLE Output (VB-Audio Virtual Cable)', 1, 2),
                   device('CABLE Input (VB-Audio Virtual Cable)', 1, outs=2),
                   device('CABLE In 16ch (VB-Audio Virtual Cable)', 1, outs=2)]
        inputs = device_choices(devices, hosts, 'input')
        outputs = device_choices(devices, hosts, 'output')
        self.assertEqual(set(inputs.values()), {2, 3})
        self.assertEqual(set(outputs.values()), {5})
        self.assertTrue(any('Realtek' in label for label in inputs))
        self.assertTrue(any('Web Camera' in label for label in inputs))

    def test_falls_back_to_host_with_usable_inputs(self):
        hosts = [{'name': 'MME'}, {'name': 'Windows WASAPI'}]
        devices = [{'name': 'USB mic', 'hostapi': 0, 'max_input_channels': 1,
                    'max_output_channels': 0},
                   {'name': 'Speaker', 'hostapi': 1, 'max_input_channels': 0,
                    'max_output_channels': 2}]
        self.assertEqual(list(device_choices(devices, hosts, 'input').values()), [0])


if __name__ == '__main__':
    unittest.main()
