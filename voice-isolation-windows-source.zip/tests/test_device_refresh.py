from types import SimpleNamespace
from unittest import TestCase
from unittest.mock import MagicMock, patch

import app


class Value:
    def __init__(self, value=''):
        self.value = value

    def get(self):
        return self.value

    def set(self, value):
        self.value = value


class DeviceRefreshTests(TestCase):
    def make_app(self):
        window = app.VoiceApp.__new__(app.VoiceApp)
        window.busy = False
        window.engine = None
        window.input_combo = {}
        window.output_combo = {}
        window.input_var = Value()
        window.output_var = Value()
        window.status_var = Value()
        window.update_output_info = MagicMock()
        return window

    def test_refresh_reloads_portaudio_before_querying_devices(self):
        window = self.make_app()
        devices = [
            {'name': 'Microphone', 'hostapi': 0, 'max_input_channels': 1, 'max_output_channels': 0},
            {'name': 'CABLE Input', 'hostapi': 0, 'max_input_channels': 0, 'max_output_channels': 1},
        ]
        hosts = [{'name': 'Windows WASAPI'}]
        calls = []
        with patch.object(app.sd, '_terminate', side_effect=lambda: calls.append('terminate')), \
             patch.object(app.sd, '_initialize', side_effect=lambda: calls.append('initialize')), \
             patch.object(app.sd, 'query_devices', side_effect=lambda: calls.append('query') or devices), \
             patch.object(app.sd, 'query_hostapis', return_value=hosts), \
             patch.object(app.sd, 'default', SimpleNamespace(device=(0, 1))):
            window.refresh_devices(reinitialize=True)
        self.assertEqual(calls, ['terminate', 'initialize', 'query'])
        self.assertEqual(window.inputs, {'Microphone': 0})
        self.assertEqual(window.output_var.get(), '虚拟麦克风（CABLE Input，推荐）')

    def test_refresh_does_not_interrupt_a_running_stream(self):
        window = self.make_app()
        window.engine = object()
        with patch.object(app.sd, '_terminate') as terminate:
            window.refresh_devices(reinitialize=True)
        terminate.assert_not_called()

    def test_missing_virtual_cable_is_not_replaced_with_speakers(self):
        window = self.make_app()
        window.output_info = Value()
        window.update_output_info = lambda: app.VoiceApp.update_output_info(window)
        devices = [
            {'name': 'Microphone', 'hostapi': 0, 'max_input_channels': 1, 'max_output_channels': 0},
            {'name': 'Speakers', 'hostapi': 0, 'max_input_channels': 0, 'max_output_channels': 2},
        ]
        with patch.object(app.sd, 'query_devices', return_value=devices), \
             patch.object(app.sd, 'query_hostapis', return_value=[{'name': 'Windows WASAPI'}]), \
             patch.object(app.sd, 'default', SimpleNamespace(device=(0, 1))):
            window.refresh_devices()
        self.assertEqual(window.output_var.get(), '')
        self.assertIn('未找到虚拟声卡', window.output_info.get())

    def test_refresh_does_not_invalidate_an_open_comparison_dialog(self):
        window = self.make_app()
        window.comparison_window = MagicMock()
        window.comparison_window.winfo_exists.return_value = True
        with patch.object(app.sd, '_terminate') as terminate, \
             patch.object(app.messagebox, 'showinfo') as message:
            window.refresh_devices(reinitialize=True)
        terminate.assert_not_called()
        message.assert_called_once()
