"""Closing to the tray must never stop audio; explicit exit must stop it."""
import queue
import unittest
from unittest import mock

import app


class TrayIntegrationTests(unittest.TestCase):
    def make_app(self, available=True):
        window = app.VoiceApp.__new__(app.VoiceApp)
        window.root = mock.Mock()
        window.tray = mock.Mock()
        window.tray.available = available
        window.instance_guard = mock.Mock()
        window.comparison_window = None
        window._comparison_hidden = False
        window.engine = mock.Mock()
        window.busy = False
        window.closing = False
        window.run_generation = 0
        window.pending_stream_error = None
        window.start_button = mock.Mock()
        window.stop_button = mock.Mock()
        window.status_var = mock.Mock()
        window.events = queue.Queue()
        return window

    def test_close_hides_window_and_keeps_processing(self):
        window = self.make_app()
        engine = window.engine
        window.close()
        window.root.withdraw.assert_called_once()
        engine.stop.assert_not_called()
        window.tray.stop.assert_not_called()
        self.assertIs(window.engine, engine)

    def test_explicit_quit_stops_audio_tray_and_guard(self):
        window = self.make_app()
        engine = window.engine
        self.assertTrue(window.quit_app())
        engine.stop.assert_called_once()
        window.tray.stop.assert_called_once()
        window.instance_guard.close.assert_called_once()
        window.root.destroy.assert_called_once()

    def test_missing_tray_closes_instead_of_hiding_unrecoverably(self):
        window = self.make_app(available=False)
        engine = window.engine
        window.close()
        window.root.withdraw.assert_not_called()
        engine.stop.assert_called_once()
        window.root.destroy.assert_called_once()

    def test_quit_while_busy_restores_window_without_stopping_work(self):
        window = self.make_app()
        window.busy = True
        engine = window.engine
        with mock.patch.object(app.messagebox, 'showinfo') as notice:
            self.assertFalse(window.quit_app())
        window.root.deiconify.assert_called_once()
        engine.stop.assert_not_called()
        window.root.destroy.assert_not_called()
        notice.assert_called_once()

    def test_tray_show_event_reopens_window_on_poll(self):
        window = self.make_app()
        window.engine = None
        window.instance_guard = None
        window.events.put(('tray_show', None))
        window.poll()
        window.root.deiconify.assert_called_once()
        window.root.lift.assert_called_once()

    def test_tray_failure_recovers_hidden_window(self):
        window = self.make_app()
        window.engine = None
        window.instance_guard = None
        window.tray_hint_var = mock.Mock()
        window.events.put(('tray_failed', '失去托盘'))
        with mock.patch.object(app.messagebox, 'showwarning') as notice:
            window.poll()
        window.root.deiconify.assert_called_once()
        notice.assert_called_once()

    def test_minimize_only_hides_when_tray_available(self):
        window = self.make_app()
        window.root.winfo_exists.return_value = True
        window.root.state.return_value = 'iconic'
        window._hide_if_minimized()
        window.root.withdraw.assert_called_once()
        window.root.withdraw.reset_mock()
        window.tray.available = False
        window._hide_if_minimized()
        window.root.withdraw.assert_not_called()


if __name__ == '__main__':
    unittest.main()
